The file P2random.h is needed for PR mode.

The spec input files (DL and PR) are included, along with correct
output for various flags (none, just v, just m, just g, just w).

There is also a larger sample input file to use, along with output
with various flag combinations turned on.  If you don't have verbose
or movie watcher mode, just look for the "End of Day" portion of
large-vw-out.txt.

The output should be the same no matter which input file (DL or PR)
it is run with.
